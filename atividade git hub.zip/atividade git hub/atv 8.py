def clean():
    print('\n' * 100)
    clean()

numero = int(input('Digite um inteiro: '))

if (numero%2) == 0:
        print("Par")
else:
        print("Ímpar")
