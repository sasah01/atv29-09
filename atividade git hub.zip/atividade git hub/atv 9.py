def clean():
    print('\n' * 100)
    clean()

n1 = int(input('Digite um valor para A: '))
n2 = int(input('Digite um valor para B: '))

c = n1
d = n2

print('agora os valores são: ', d, c)