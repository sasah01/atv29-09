def clean():
    print('\n' * 100)
    clean()

valor = 634

n50 = (valor) // 50
r50 = (valor) % 50

n10 = (n50) // 10
r10 = (r50) % 10

n1 = (n10) // 1
r1 = (n10) % 1

print('cedulas de 50:', n50)

print('cedulas de 10:', n10)

print('cedulas de 1:', n1)


