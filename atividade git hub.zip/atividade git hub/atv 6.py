def clean():
    print('\n' * 100)
    clean()
print('Hoje esta fazendo 32 gruas e em fahenheit é:')

cel = 32

fire = ((cel * 9) /5 ) + 32

print(fire)





